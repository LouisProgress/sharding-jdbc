package xyz.zhouzhaodong.springbootscrew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootScrewApplicationTests {

    @Test
    void contextLoads() {
    }

}
