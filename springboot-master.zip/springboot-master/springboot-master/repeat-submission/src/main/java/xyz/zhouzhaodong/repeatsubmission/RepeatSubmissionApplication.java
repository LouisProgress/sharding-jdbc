package xyz.zhouzhaodong.repeatsubmission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepeatSubmissionApplication {

    public static void main(String[] args) {
        SpringApplication.run(RepeatSubmissionApplication.class, args);
    }

}
