package xyz.zhouzhaodong.html2image;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Html2imageApplication {

    public static void main(String[] args) {
        SpringApplication.run(Html2imageApplication.class, args);
    }

}
