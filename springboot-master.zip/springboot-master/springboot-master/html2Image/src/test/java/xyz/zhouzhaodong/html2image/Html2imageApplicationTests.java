package xyz.zhouzhaodong.html2image;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Html2imageApplicationTests {

    @Test
    void contextLoads() {
    }

}
