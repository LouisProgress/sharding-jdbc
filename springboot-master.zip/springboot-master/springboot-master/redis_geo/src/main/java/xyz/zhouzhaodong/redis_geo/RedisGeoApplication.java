package xyz.zhouzhaodong.redis_geo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisGeoApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedisGeoApplication.class, args);
    }

}
