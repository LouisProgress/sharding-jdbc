package xyz.zhouzhaodong.springbootjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
