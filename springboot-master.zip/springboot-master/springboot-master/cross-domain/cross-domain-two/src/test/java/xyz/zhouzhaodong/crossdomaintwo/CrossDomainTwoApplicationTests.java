package xyz.zhouzhaodong.crossdomaintwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrossDomainTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
