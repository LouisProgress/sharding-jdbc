package xyz.zhouzhaodong.crossdomaintwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrossDomainTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrossDomainTwoApplication.class, args);
	}

}
