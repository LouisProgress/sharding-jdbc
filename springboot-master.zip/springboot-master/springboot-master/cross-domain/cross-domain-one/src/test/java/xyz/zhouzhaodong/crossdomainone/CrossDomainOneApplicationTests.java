package xyz.zhouzhaodong.crossdomainone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrossDomainOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
