package xyz.zhouzhaodong.crossdomainone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrossDomainOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrossDomainOneApplication.class, args);
	}

}
