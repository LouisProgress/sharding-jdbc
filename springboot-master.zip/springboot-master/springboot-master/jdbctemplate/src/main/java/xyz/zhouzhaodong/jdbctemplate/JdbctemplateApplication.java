package xyz.zhouzhaodong.jdbctemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbctemplateApplication {

    public static void main(String[] args) {
        SpringApplication.run(JdbctemplateApplication.class, args);
    }

}
