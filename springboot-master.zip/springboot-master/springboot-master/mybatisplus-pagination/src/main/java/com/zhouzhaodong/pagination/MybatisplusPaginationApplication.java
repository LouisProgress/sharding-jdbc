package com.zhouzhaodong.pagination;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisplusPaginationApplication {

    public static void main(String[] args) {
        SpringApplication.run(MybatisplusPaginationApplication.class, args);
    }

}
