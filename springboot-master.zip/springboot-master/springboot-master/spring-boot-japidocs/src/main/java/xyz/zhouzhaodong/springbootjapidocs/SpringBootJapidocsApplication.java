package xyz.zhouzhaodong.springbootjapidocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJapidocsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJapidocsApplication.class, args);
    }

}
